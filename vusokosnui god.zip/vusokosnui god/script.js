const button = document.getElementById("btn");
const daysResult = document.getElementById("daysResult");
const leapResult = document.getElementById("leapResult");

function getDaysToNewYear(dateString) {
    const [day, month, year] = dateString.split(".").map(Number);

    const currentDate = new Date(year, month - 1, day);

    // 31.12.гггг
    const newYearDate = new Date(year, 11, 31);

    const diff = newYearDate - currentDate;

    return Math.ceil(diff / (1000 * 60 * 60 * 24));
}

function isLeapYear(year) {
    return (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0;
}

button.addEventListener("click", () => {
    const value = document.getElementById("dateInput").value;

    if (!/^\d{2}\.\d{2}\.\d{4}$/.test(value)) {
        daysResult.textContent = "Введите дату в формате дд.мм.гггг";
        leapResult.textContent = "";
        return;
    }

    const [, , year] = value.split(".").map(Number);

    const days = getDaysToNewYear(value);

    daysResult.textContent =
        `До Нового года осталось ${days} дней`;

    leapResult.textContent =
        isLeapYear(year)
            ? "Год високосный"
            : "Год не високосный";
});